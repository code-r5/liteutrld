# Strings Analytics


| Code | Language | Translated | Remaining |
|----|-------|-------|---|
| en | English [English] | 413 | 0 |
| ka | Kannada [ಕನ್ನಡ] | 114 | 299 |
| bn | bengoli [বাংলা] | 114 | 299 |
| od | Odia [ଓଡିଆ] | 114 | 299 |
| ru | Russian [Русский] | 413 | 0 |
| pt-br | Portuguese [Português] | 413 | 0 |
| my | Malay [Bahasa Melayu] | 114 | 299 |
| jp | Japanese [日本] | 416 | -3 |
| tr | Turkish [Türk] | 114 | 299 |
| si | sinhala [සිංහල] | 114 | 299 |
| fa | Persian [Farsi] | 391 | 22 |
| hi | Hindi [हिंदी] | 410 | 3 |
| az | Azerbaijan [Azərbaycan] | 382 | 31 |
| id | Indonesia [Indonesia] | 413 | 0 |
| cn | Chinese [简体中文] | 114 | 299 |
| ta | தமிழ் [தமிழ்] | 114 | 299 |
| mr | Marathi [मराठी] | 114 | 299 |
| ar | Arabic [العربية] | 413 | 0 |
| it | Italian [italiano] | 113 | 300 |
| gu | Gujarati [ગુજરાતી] | 111 | 302 |
| ml | Malayalam [മലയാളം] | 114 | 299 |
| es | Spanish [Español] | 114 | 299 |


If Strings are not present, Google Translation will be used to Translate them at time of Usage.
<br>• Remaining Strings can be found [here](./remaining.csv) for easy sort out.
